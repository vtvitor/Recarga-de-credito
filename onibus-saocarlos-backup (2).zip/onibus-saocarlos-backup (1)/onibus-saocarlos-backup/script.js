(() => {
  "use strict";

  const state = {
    map: null,
    markers: new Map(),
    activeLines: new Set(),
    selectedPointId: null
  };

  function initMap() {
    state.map = L.map("map", { zoomControl: true }).setView(
      BUS_DATA.center,
      BUS_DATA.zoom
    );

    L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
      maxZoom: 19,
      attribution:
        '© <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>'
    }).addTo(state.map);
  }

  function createMarkerIcon(point) {
    const isTerminal = point.type === "terminal";
    const className = "bus-marker" + (isTerminal ? " terminal" : "");
    const symbol = isTerminal ? "T" : "•";
    return L.divIcon({
      className: "",
      html: `<div class="${className}">${symbol}</div>`,
      iconSize: isTerminal ? [38, 38] : [32, 32],
      iconAnchor: isTerminal ? [19, 19] : [16, 16]
    });
  }

  function buildPopupContent(point) {
    const lineTags = point.lines
      .map((ln) => {
        const info = BUS_DATA.lines[ln];
        return `<span class="line-tag ${info?.color || ""}">${ln}</span>`;
      })
      .join(" ");

    return `
      <h4>${point.name}</h4>
      <div class="popup-address">${point.address}</div>
      <div><strong>Linhas:</strong> ${lineTags}</div>
      <a href="#" class="popup-link" data-point-id="${point.id}">Ver detalhes →</a>
    `;
  }

  function renderMarkers() {
    BUS_DATA.points.forEach((point) => {
      const marker = L.marker([point.lat, point.lng], {
        icon: createMarkerIcon(point)
      })
        .addTo(state.map)
        .bindPopup(buildPopupContent(point));

      marker.on("popupopen", (e) => {
        const link = e.popup.getElement().querySelector(".popup-link");
        if (link) {
          link.addEventListener("click", (ev) => {
            ev.preventDefault();
            selectPoint(point.id);
          });
        }
      });

      state.markers.set(point.id, marker);
    });
  }

  function renderLineFilters() {
    const container = document.getElementById("lineFilters");
    container.innerHTML = "";

    Object.entries(BUS_DATA.lines).forEach(([num, info]) => {
      const chip = document.createElement("div");
      chip.className = "line-chip";
      chip.dataset.line = num;
      chip.textContent = num;
      chip.title = info.name;
      chip.addEventListener("click", () => toggleLine(num, chip));
      container.appendChild(chip);
    });
  }

  function toggleLine(lineNumber, chipEl) {
    if (state.activeLines.has(lineNumber)) {
      state.activeLines.delete(lineNumber);
      chipEl.classList.remove("active");
    } else {
      state.activeLines.add(lineNumber);
      chipEl.classList.add("active");
    }
    applyFilters();
  }

  function applyFilters() {
    const searchText = document
      .getElementById("searchInput")
      .value.trim()
      .toLowerCase();

    state.markers.forEach((marker, pointId) => {
      const point = BUS_DATA.points.find((p) => p.id === pointId);

      let visible = true;

      if (state.activeLines.size > 0) {
        const intersect = point.lines.some((ln) =>
          state.activeLines.has(ln)
        );
        if (!intersect) visible = false;
      }

      if (visible && searchText) {
        visible = matchesSearch(point, searchText);
      }

      if (visible) {
        marker.addTo(state.map);
      } else {
        state.map.removeLayer(marker);
      }
    });
  }

  function matchesSearch(point, text) {
    if (point.name.toLowerCase().includes(text)) return true;
    if (point.address.toLowerCase().includes(text)) return true;
    if (point.lines.some((ln) => ln === text)) return true;
    for (const ln of point.lines) {
      const info = BUS_DATA.lines[ln];
      if (info && info.name.toLowerCase().includes(text)) return true;
    }
    return false;
  }

  function selectPoint(pointId) {
    state.selectedPointId = pointId;
    const point = BUS_DATA.points.find((p) => p.id === pointId);
    if (!point) return;

    const panel = document.getElementById("infoPanel");
    panel.innerHTML = buildPointPanel(point);

    state.map.setView([point.lat, point.lng], 15, { animate: true });
    const marker = state.markers.get(pointId);
    if (marker) marker.openPopup();
  }

  function buildPointPanel(point) {
    const linesHtml = point.lines
      .map((ln) => {
        const info = BUS_DATA.lines[ln];
        return `<span class="line-tag ${info?.color || ""}" title="${info?.name || ""}">${ln}</span>`;
      })
      .join(" ");

    const schedulesHtml = point.lines
      .map((ln) => buildScheduleForLine(ln))
      .join("");

    return `
      <div class="point-name">${point.name}</div>
      <div class="point-address">📍 ${point.address}</div>
      <h3>🚌 Linhas que passam aqui</h3>
      <div>${linesHtml}</div>
      <h3 style="margin-top:18px">⏰ Horários</h3>
      ${schedulesHtml}
      <p class="disclaimer">
        ⚠️ Horários <strong>referenciais</strong>. Confirme no próprio ponto
        ou pelo app Moovit antes de sair.
      </p>
      <p style="margin-top:12px;font-size:0.8rem;color:#78909c">
        Operadora: <strong>${BUS_DATA.operator}</strong>
      </p>
    `;
  }

  function buildScheduleForLine(lineNumber) {
    const info = BUS_DATA.lines[lineNumber];
    const schedule = getScheduleForLine(lineNumber);
    if (!schedule) return "";

    const rows = ["weekday", "saturday", "sunday"]
      .map((dayKey) => {
        const times = schedule[dayKey];
        if (!times || times.length === 0) return "";
        const label =
          dayKey === "weekday" ? "Dias úteis" :
          dayKey === "saturday" ? "Sábado" : "Domingo";
        const timesStr = times.map((t) => `<span class="line-tag">${t}</span>`).join(" ");
        return `
          <tr>
            <th>${label}</th>
            <td>${timesStr}</td>
          </tr>
        `;
      })
      .join("");

    return `
      <div style="margin-top:10px">
        <h4 style="font-size:0.9rem;color:#1565c0">
          Linha ${lineNumber} — ${info?.name || ""}
        </h4>
        <table class="time-table">${rows}</table>
      </div>
    `;
  }

  function initSearch() {
    const input = document.getElementById("searchInput");
    input.addEventListener("input", () => {
      applyFilters();
      if (state.selectedPointId) {
        const point = BUS_DATA.points.find(
          (p) => p.id === state.selectedPointId
        );
        const matches = matchesSearch(
          point,
          input.value.trim().toLowerCase()
        );
        if (!matches) {
          state.selectedPointId = null;
          resetInfoPanel();
        }
      }
    });
  }

  function resetInfoPanel() {
    const panel = document.getElementById("infoPanel");
    panel.innerHTML = `
      <h2>Bem-vindo!</h2>
      <p>Clique em um marcador no mapa para ver:</p>
      <ul>
        <li>📍 Endereço do ponto</li>
        <li>🚌 Linhas que passam</li>
        <li>⏰ Horários</li>
      </ul>
      <p class="disclaimer">
        <strong>Atenção:</strong> Os horários são referenciais.
      </p>
    `;
  }

  function getPointById(id) {
    return BUS_DATA.points.find((p) => p.id === id) || null;
  }

  function pointLabel(p) {
    return p ? p.name : "(desconhecido)";
  }

  function linesPassingAt(pointId) {
    const p = getPointById(pointId);
    return p ? p.lines.slice() : [];
  }

  function escapeHtml(str) {
    return String(str)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&#39;");
  }

  function initTabs() {
    document.querySelectorAll(".tab-btn").forEach((btn) => {
      btn.addEventListener("click", () => switchView(btn.dataset.view));
    });
  }

  function switchView(name) {
    document.querySelectorAll(".tab-btn").forEach((b) =>
      b.classList.toggle("active", b.dataset.view === name)
    );
    document.getElementById("mapSidebar").style.display =
      name === "map" ? "flex" : "none";
    document.getElementById("cardView").style.display =
      name === "card" ? "flex" : "none";
    document.getElementById("routeView").style.display =
      name === "route" ? "flex" : "none";
    document.getElementById("map").style.display =
      name === "map" ? "block" : "none";
    if (name === "map") {
      setTimeout(() => state.map.invalidateSize(), 50);
    }
  }

  const CardManager = {
    KEY: "buspass.cards.v1",

    toCentavos(reais) { return Math.round(Number(reais) * 100); },
    toReais(centavos) { return (Number(centavos) / 100).toFixed(2); },
    onlyDigits(str) { return (str || "").replace(/\D/g, ""); },

    async listar() {
      const s = Auth.getSession();
      if (!s) return [];
      const resp = await API.listarCartoes(s.id);
      if (resp && !resp.offline) return resp;
      return this.loadLocal().filter(c => c.usuarioId == s.id);
    },

    async criar(dados) {
      const s = Auth.getSession();
      const payload = {
        usuarioId: s.id,
        nome: dados.name,
        cpf: this.onlyDigits(dados.cpf),
        numero: dados.number,
        saldoCentavos: this.toCentavos(dados.balance)
      };
      const resp = await API.criarCartao(payload);
      if (resp && !resp.offline) return resp;
      const local = this.loadLocal();
      const novo = {
        id: "c" + Date.now(),
        usuarioId: s.id,
        nome: dados.name,
        cpf: payload.cpf,
        numero: dados.number,
        saldoCentavos: payload.saldoCentavos,
        recargas: 0
      };
      local.push(novo);
      this.saveLocal(local);
      return novo;
    },

    async recarregar(id, valorReais) {
  const valorCentavos = this.toCentavos(valorReais);
  const resp = await API.recarregarCartao(id, valorCentavos);

  if (resp && !resp.offline) {
    return {
      ok: true,
      novoSaldo: resp.novoSaldoCentavos,
      recargas: resp.recargas
    };
  }

  const local = this.loadLocal();
  const c = local.find(x => x.id == id);

  if (!c) return { ok:false, msg:"Cartão não encontrado." };

  c.saldoCentavos += valorCentavos;
  c.recargas = (c.recargas || 0) + 1;

  this.saveLocal(local);

  return {
    ok:true,
    novoSaldo:c.saldoCentavos,
    recargas:c.recargas
  };
},

    async deletar(id) {
      const resp = await API.deletarCartao(id);
      if (resp && !resp.offline) return true;
      const local = this.loadLocal().filter(c => c.id != id);
      this.saveLocal(local);
      return true;
    },

    loadLocal() {
      try { return JSON.parse(localStorage.getItem(this.KEY) || "[]"); }
      catch { return []; }
    },
    saveLocal(list) { localStorage.setItem(this.KEY, JSON.stringify(list)); },

    maskCardNumber(num) {
      const s = String(num || "").trim();
      if (s.length <= 4) return s;
      return "*".repeat(s.length - 4) + s.slice(-4);
    },

    maskCpf(cpf) {
      const d = this.onlyDigits(cpf);
      if (d.length !== 11) return cpf;
      return `${d.slice(0, 3)}.${d.slice(3, 6)}.***.**-${d.slice(10)}`;
    },

    formatCpfInput(value) {
      const d = this.onlyDigits(value).slice(0, 11);
      let out = d;
      if (d.length > 3) out = d.slice(0, 3) + "." + d.slice(3);
      if (d.length > 6) out = d.slice(0, 3) + "." + d.slice(3, 6) + "." + d.slice(6);
      if (d.length > 9) out = d.slice(0, 3) + "." + d.slice(3, 6) + "." + d.slice(6, 9) + "-" + d.slice(9);
      return out;
    },

    async render(container) {
      const cartoes = await this.listar();
      if (!cartoes.length) {
        container.innerHTML = `<p class="empty-msg">Nenhum cartão cadastrado ainda.</p>`;
        return;
      }

      container.innerHTML = cartoes.map(c => {
        const quick = [10, 20, 50, 100].map(v =>
          `<button type="button" class="quick-amt" data-quick="${v}" data-card-id="${c.id}">+R$${v}</button>`
        ).join("");
        const saldoReais = this.toReais(c.saldoCentavos);

        return `
          <div class="card-item" data-card-id="${c.id}">
            <div class="card-item-head">
              <div>
                <div class="card-item-name">${escapeHtml(c.nome || "")}</div>
                <div class="card-item-cpf">CPF ${this.maskCpf(c.cpf)}</div>
              </div>
            </div>
            <div class="card-item-number">💳 ${this.maskCardNumber(c.numero)}</div>
            <div class="card-item-balance">
              Saldo: <strong data-balance>R$ ${saldoReais}</strong>
            </div>
            <div class="recharge-box">
              <div class="recharge-title">💰 Carregar saldo</div>
              <div class="recharge-row">
                <input type="number" min="1" max="1000" step="0.01"
                       placeholder="Valor (R$)" data-recharge-input="${c.id}" />
                <button type="button" class="btn btn-primary recharge-btn"
                        data-recharge-id="${c.id}">Recarregar</button>
              </div>
              <div class="recharge-quick">${quick}</div>
              <p class="recharge-feedback" data-feedback="${c.id}"></p>
            </div>
            <div class="card-item-actions">
              <span class="recharge-count" data-recharge-count>
  ${c.recargas || 0} recarga(s)
</span>
              <button class="btn btn-danger" data-remove-id="${c.id}">Excluir</button>
            </div>
          </div>
        `;
      }).join("");

      container.querySelectorAll("[data-remove-id]").forEach(btn => {
        btn.addEventListener("click", async () => {
          await this.deletar(btn.dataset.removeId);
          this.render(container);
        });
      });

      container.querySelectorAll("[data-recharge-id]").forEach(btn => {
        btn.addEventListener("click", async () => {
          const id = btn.dataset.rechargeId;
          const input = container.querySelector(`[data-recharge-input="${id}"]`);
          const fb = container.querySelector(`[data-feedback="${id}"]`);
          await this.fazerRecarga(id, input.value, fb, container);
          input.value = "";
        });
      });

      container.querySelectorAll("[data-quick]").forEach(btn => {
        btn.addEventListener("click", async () => {
          const id = btn.dataset.cardId;
          const valor = btn.dataset.quick;
          const fb = container.querySelector(`[data-feedback="${id}"]`);
          await this.fazerRecarga(id, valor, fb, container);
        });
      });

      container.querySelectorAll("[data-recharge-input]").forEach(input => {
        input.addEventListener("keydown", async (e) => {
          if (e.key === "Enter") {
            e.preventDefault();
            const id = input.dataset.rechargeInput;
            const fb = container.querySelector(`[data-feedback="${id}"]`);
            await this.fazerRecarga(id, input.value, fb, container);
            input.value = "";
          }
        });
      });
    },

    async fazerRecarga(id, valor, fb, container) {
      const r = await this.recarregar(id, valor);
      if (!r.ok) {
        fb.textContent = "❌ " + r.msg;
        fb.className = "recharge-feedback error";
        return;
      }
      const v = Number(valor);
      const novoReais = (r.novoSaldo / 100).toFixed(2);
      fb.textContent = `✅ Recarga de R$ ${v.toFixed(2)} feita! Novo saldo: R$ ${novoReais}`;
      fb.className = "recharge-feedback success";

      const cardEl = container.querySelector(`.card-item[data-card-id="${id}"]`);
      if (cardEl) {

  cardEl.querySelector("[data-balance]").textContent = `R$ ${novoReais}`;

 
  const countEl = cardEl.querySelector("[data-recharge-count]");
  if (countEl) {
    const atual = Number(countEl.textContent.match(/\d+/)?.[0] || 0);
    countEl.textContent = `${atual + 1} recarga(s)`;
  }
}
      setTimeout(() => {
        if (fb.textContent.startsWith("✅")) {
          fb.textContent = "";
          fb.className = "recharge-feedback";
        }
      }, 5000);
    }
  };

  function initCardView() {
    const form = document.getElementById("cardForm");
    const errEl = document.getElementById("cardError");
    const cpfInput = document.getElementById("cardCpf");
    const listEl = document.getElementById("cardList");

    cpfInput.addEventListener("input", (e) => {
      e.target.value = CardManager.formatCpfInput(e.target.value);
    });

    form.addEventListener("submit", async (ev) => {
      ev.preventDefault();
      errEl.textContent = "";

      const card = {
        name: document.getElementById("cardName").value.trim(),
        cpf: document.getElementById("cardCpf").value,
        number: document.getElementById("cardNumber").value.trim(),
        balance: document.getElementById("cardBalance").value
      };

      if (card.name.length < 3) { errEl.textContent = "Nome inválido."; return; }
      if (CardManager.onlyDigits(card.cpf).length !== 11) {
        errEl.textContent = "CPF deve ter 11 dígitos."; return;
      }
      if (card.number.length < 6) {
        errEl.textContent = "Número do cartão muito curto."; return;
      }
      if (Number(card.balance) < 0) {
        errEl.textContent = "Saldo não pode ser negativo."; return;
      }

      const btn = ev.target.querySelector("button");
      btn.disabled = true;
      btn.textContent = "Cadastrando...";
      await CardManager.criar(card);
      btn.disabled = false;
      btn.textContent = "Cadastrar cartão";
      form.reset();
      CardManager.render(listEl);
    });

    CardManager.render(listEl);
  }

  const RoutePlanner = {
    findDirect(originId, destId) {
      const results = [];
      Object.entries(BUS_DATA.routes).forEach(([ln, stops]) => {
        const oi = stops.indexOf(originId);
        const di = stops.indexOf(destId);
        if (oi === -1 || di === -1) return;
        const lo = Math.min(oi, di);
        const hi = Math.max(oi, di);
        results.push({
          kind: "direct",
          line: ln,
          direction: di > oi ? "ida" : "volta",
          stops: stops.slice(lo, hi + 1),
          totalStops: hi - lo
        });
      });
      return results.sort((a, b) => a.totalStops - b.totalStops);
    },

    findWithTransfer(originId, destId) {
      const results = [];
      const linesAtOrigin = linesPassingAt(originId);
      const linesAtDest = linesPassingAt(destId);

      linesAtOrigin.forEach((lnA) => {
        const routeA = BUS_DATA.routes[lnA] || [];
        const oiA = routeA.indexOf(originId);
        if (oiA === -1) return;

        linesAtDest.forEach((lnB) => {
          if (lnA === lnB) return;
          const routeB = BUS_DATA.routes[lnB] || [];
          const diB = routeB.indexOf(destId);
          if (diB === -1) return;

          routeA.slice(oiA + 1).forEach((transferId) => {
            if (!routeB.includes(transferId)) return;
            if (transferId === destId) return;
            const tiA = routeA.indexOf(transferId);
            const tiB = routeB.indexOf(transferId);
            const segA = routeA.slice(oiA, tiA + 1);
            const segB = routeB.slice(tiB, diB + 1);
            const key = `${lnA}|${transferId}|${lnB}`;
            if (results.some((r) => r.key === key)) return;
            results.push({
              kind: "transfer",
              key,
              lineA: lnA,
              lineB: lnB,
              transferAt: transferId,
              segmentA: segA,
              segmentB: segB,
              totalStops: segA.length + segB.length - 1
            });
          });
        });
      });

      return results.sort((a, b) => a.totalStops - b.totalStops);
    },

    focusOnMap(originId, destId) {
      const o = getPointById(originId);
      const d = getPointById(destId);
      if (!o || !d) return;
      switchView("map");
      const bounds = L.latLngBounds([
        [o.lat, o.lng],
        [d.lat, d.lng]
      ]);
      state.map.fitBounds(bounds, { padding: [60, 60] });
      const marker = state.markers.get(originId);
      if (marker) marker.openPopup();
    },

    render(results, container, originId, destId) {
      if (!results.direct.length && !results.transfer.length) {
        container.innerHTML = `
          <div class="route-no-result">
            😕 Nenhuma rota encontrada.
          </div>
        `;
        return;
      }

      const directHtml = results.direct.map((r) => this.renderDirectCard(r)).join("");
      const transferHtml = results.transfer
        .slice(0, 5)
        .map((r) => this.renderTransferCard(r))
        .join("");

      container.innerHTML = `
        ${directHtml ? `<h3>🚌 Diretas</h3>${directHtml}` : ""}
        ${transferHtml ? `<h3>🔁 Com baldeação</h3>${transferHtml}` : ""}
      `;

      container.querySelectorAll("[data-focus]").forEach((el) => {
        el.addEventListener("click", () => this.focusOnMap(originId, destId));
      });
    },

    renderDirectCard(r) {
      const lineInfo = BUS_DATA.lines[r.line];
      const stopsNames = r.stops.map((id) => pointLabel(getPointById(id)));
      const intermediate = stopsNames.slice(1, -1);
      const total = r.stops.length;
      const stopsHtml = stopsNames
        .map(
          (n, i) =>
            `<li>${escapeHtml(n)}${i === 0 ? " <em>(origem)</em>" : i === total - 1 ? " <em>(destino)</em>" : ""}</li>`
        )
        .join("");

      return `
        <div class="route-card" data-focus="1">
          <div class="route-card-title">
            <span class="badge">Linha ${escapeHtml(r.line)}</span>
            ${escapeHtml(lineInfo?.name || "")}
          </div>
          <div class="route-card-line">
            Sentido: <strong>${r.direction === "ida" ? "ida" : "volta"}</strong>
            · ${intermediate.length} ponto(s) intermediário(s)
          </div>
          <div class="route-card-stops">
            <ol>${stopsHtml}</ol>
          </div>
        </div>
      `;
    },

    renderTransferCard(r) {
      const lineAInfo = BUS_DATA.lines[r.lineA];
      const lineBInfo = BUS_DATA.lines[r.lineB];
      const firstNames = r.segmentA.map((id) => pointLabel(getPointById(id)));
      const secondNames = r.segmentB.slice(1).map((id) => pointLabel(getPointById(id)));
      const transferName = pointLabel(getPointById(r.transferAt));

      return `
        <div class="route-card transfer" data-focus="1">
          <div class="route-card-title">
            <span class="badge">Linha ${escapeHtml(r.lineA)} → Linha ${escapeHtml(r.lineB)}</span>
            ${escapeHtml(lineAInfo?.name || "")} → ${escapeHtml(lineBInfo?.name || "")}
          </div>
          <div class="route-card-line">
            Trocar em <strong>${escapeHtml(transferName)}</strong>
          </div>
          <div class="route-card-stops">
            <strong>1º trecho:</strong>
            <ol>${firstNames.map((n) => `<li>${escapeHtml(n)}</li>`).join("")}</ol>
            <div class="transfer-marker">🔁 Baldeação em ${escapeHtml(transferName)}</div>
            <strong>2º trecho:</strong>
            <ol start="${firstNames.length}">${secondNames.map((n) => `<li>${escapeHtml(n)}</li>`).join("")}</ol>
          </div>
        </div>
      `;
    }
  };

  function initRouteView() {
    const originSel = document.getElementById("routeOrigin");
    const destSel = document.getElementById("routeDest");

    const sorted = BUS_DATA.points.slice().sort((a, b) =>
      a.name.localeCompare(b.name, "pt-BR")
    );
    const optionsHtml = sorted
      .map((p) => `<option value="${p.id}">${escapeHtml(p.name)}</option>`)
      .join("");
    originSel.innerHTML = optionsHtml;
    destSel.innerHTML = optionsHtml;

    if (sorted.length >= 2) {
      originSel.value = sorted[0].id;
      destSel.value = sorted[1].id;
    }

    document.getElementById("routeForm").addEventListener("submit", (ev) => {
      ev.preventDefault();
      const originId = originSel.value;
      const destId = destSel.value;
      if (!originId || !destId) return;
      if (originId === destId) {
        document.getElementById("routeResult").innerHTML = `
          <div class="route-no-result">Origem e destino são iguais 🙂</div>
        `;
        return;
      }
      const direct = RoutePlanner.findDirect(originId, destId);
      const transfer = RoutePlanner.findWithTransfer(originId, destId);
      RoutePlanner.render(
        { direct, transfer },
        document.getElementById("routeResult"),
        originId,
        destId
      );
    });
  }

  const Auth = {
    SESSION_KEY: "buspass.session.v1",

    onlyDigits(str) { return (str || "").replace(/\D/g, ""); },

    isValidEmail(email) {
      return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(String(email || ""));
    },

    validar(dados) {
      if (!dados.nome || dados.nome.trim().length < 3)
        return "Nome deve ter no mínimo 3 letras.";
      if (!this.isValidEmail(dados.email))
        return "E-mail inválido.";
      if (this.onlyDigits(dados.cpf).length !== 11)
        return "CPF deve ter 11 dígitos.";
      if (!dados.senha || dados.senha.length < 6)
        return "Senha deve ter no mínimo 6 caracteres.";
      return null;
    },

    async register(dados) {
      const erro = this.validar(dados);
      if (erro) return { ok: false, msg: erro };

      const payload = {
        nome: dados.nome.trim(),
        email: dados.email.trim().toLowerCase(),
        cpf: this.onlyDigits(dados.cpf),
        senha: dados.senha
      };

      const resp = await API.register(payload);
      if (resp && !resp.offline) {
        const session = {
          id: resp.id,
          nome: resp.nome,
          email: resp.email,
          cpf: resp.cpf
        };
        this.saveSession(session);
        return { ok: true, session };
      }

      const users = this.loadUsers();
      if (users.some((u) => u.email === payload.email))
        return { ok: false, msg: "E-mail já cadastrado." };
      if (users.some((u) => u.cpf === payload.cpf))
        return { ok: false, msg: "CPF já cadastrado." };

      const novo = {
        id: "u" + Date.now(),
        nome: payload.nome,
        email: payload.email,
        cpf: payload.cpf,
        senha: payload.senha
      };
      users.push(novo);
      localStorage.setItem("buspass.users.v1", JSON.stringify(users));
      this.saveSession(novo);
      return { ok: true, session: novo };
    },

    async login(email, senha) {
      if (!email || !senha) return { ok: false, msg: "Informe e-mail e senha." };

      const payload = {
        email: email.trim().toLowerCase(),
        senha: senha
      };

      const resp = await API.login(payload);
      if (resp && !resp.offline) {
        const session = {
          id: resp.id,
          nome: resp.nome,
          email: resp.email,
          cpf: resp.cpf
        };
        this.saveSession(session);
        return { ok: true, session };
      }

      const users = this.loadUsers();
      const user = users.find(u => u.email === payload.email);
      if (!user || user.senha !== payload.senha)
        return { ok: false, msg: "E-mail ou senha inválidos." };

      this.saveSession(user);
      return { ok: true, session: user };
    },

    loadUsers() {
      try { return JSON.parse(localStorage.getItem("buspass.users.v1") || "[]"); }
      catch { return []; }
    },
    saveSession(s) { localStorage.setItem(this.SESSION_KEY, JSON.stringify(s)); },
    getSession() {
      try { return JSON.parse(localStorage.getItem(this.SESSION_KEY) || "null"); }
      catch { return null; }
    },
    logout() { localStorage.removeItem(this.SESSION_KEY); },

    formatCpfInput(value) {
      const d = this.onlyDigits(value).slice(0, 11);
      let out = d;
      if (d.length > 3) out = d.slice(0, 3) + "." + d.slice(3);
      if (d.length > 6) out = d.slice(0, 3) + "." + d.slice(3, 6) + "." + d.slice(6);
      if (d.length > 9) out = d.slice(0, 3) + "." + d.slice(3, 6) + "." + d.slice(6, 9) + "-" + d.slice(9);
      return out;
    },

    iniciais(nome) {
      const partes = String(nome || "").trim().split(/\s+/);
      if (!partes[0]) return "👤";
      if (partes.length === 1) return partes[0].slice(0, 2).toUpperCase();
      return (partes[0][0] + partes[partes.length - 1][0]).toUpperCase();
    }
  };

  async function backEstaOn() {
    try {
      const res = await fetch("http://localhost:8080/api/linhas");
      return res.ok;
    } catch {
      return false;
    }
  }

  function initAuth() {
    const overlay = document.getElementById("authOverlay");
    const session = Auth.getSession();

    overlay.style.display = "flex";

    if (session && (!session.id || !session.email)) {
      Auth.logout();
    }

    const sessaoValida = session && session.id && session.email;
    if (sessaoValida) {
      overlay.style.display = "none";
      mostrarUsuario(session);
      return;
    }

    backEstaOn().then(online => {
      const nota = document.getElementById("authModeNote");
      if (online) {
        nota.textContent = "✅ Conectado ao servidor Java + banco de dados.";
        nota.style.background = "#e8f5e9";
        nota.style.color = "#2e7d32";
      } else {
        nota.textContent = "⚠️ Backend offline — modo demonstração local.";
        nota.style.background = "#fff8e1";
        nota.style.color = "#5d4037";
      }
    });

    document.querySelectorAll(".auth-tab").forEach(tab => {
      tab.addEventListener("click", () => {
        const alvo = tab.dataset.authTab;
        document.querySelectorAll(".auth-tab").forEach(t =>
          t.classList.toggle("active", t === tab));
        document.getElementById("loginForm").style.display =
          alvo === "login" ? "flex" : "none";
        document.getElementById("registerForm").style.display =
          alvo === "register" ? "flex" : "none";
        document.getElementById("loginError").textContent = "";
        document.getElementById("registerError").textContent = "";
      });
    });

    document.getElementById("regCpf").addEventListener("input", e => {
      e.target.value = Auth.formatCpfInput(e.target.value);
    });

    document.getElementById("loginForm").addEventListener("submit", async ev => {
      ev.preventDefault();
      const errEl = document.getElementById("loginError");
      errEl.textContent = "";
      const btn = ev.target.querySelector("button");
      btn.disabled = true;
      btn.textContent = "Entrando...";
      const r = await Auth.login(
        document.getElementById("loginEmail").value,
        document.getElementById("loginPassword").value
      );
      btn.disabled = false;
      btn.textContent = "Entrar";
      if (!r.ok) { errEl.textContent = "❌ " + r.msg; return; }
      entrarNoApp(r.session);
    });

    document.getElementById("registerForm").addEventListener("submit", async ev => {
      ev.preventDefault();
      const errEl = document.getElementById("registerError");
      errEl.textContent = "";
      const senha = document.getElementById("regPassword").value;
      const senha2 = document.getElementById("regPassword2").value;
      if (senha !== senha2) {
        errEl.textContent = "❌ As senhas não conferem.";
        return;
      }
      const btn = ev.target.querySelector("button");
      btn.disabled = true;
      btn.textContent = "Criando conta...";
      const r = await Auth.register({
        nome: document.getElementById("regName").value,
        email: document.getElementById("regEmail").value,
        cpf: document.getElementById("regCpf").value,
        senha: senha
      });
      btn.disabled = false;
      btn.textContent = "Criar conta";
      if (!r.ok) { errEl.textContent = "❌ " + r.msg; return; }
      entrarNoApp(r.session);
    });

    function entrarNoApp(session) {
      overlay.style.display = "none";
      mostrarUsuario(session);
      boot();
    }
  }

  function mostrarUsuario(session) {
    const chip = document.getElementById("userChip");
    document.getElementById("userChipName").textContent =
      session.nome.split(/\s+/)[0];
    document.getElementById("userAvatar").textContent =
      Auth.iniciais(session.nome);
    chip.style.display = "flex";
    document.getElementById("logoutBtn").addEventListener("click", () => {
      if (!confirm("Deseja sair?")) return;
      Auth.logout();
      location.reload();
    });
  }

  function boot() {
    initMap();
    renderMarkers();
    renderLineFilters();
    initSearch();
    initTabs();
    initCardView();
    initRouteView();
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", () => {
      initAuth();
      if (Auth.getSession()) boot();
    });
  } else {
    initAuth();
    if (Auth.getSession()) boot();
  }
})();
