/* =========================================================
   Dados de pontos e linhas de ônibus de São Carlos - SP
   BUSSPAY - Mapa de pontos de ônibus
   Fonte: informações públicas da Prefeitura de São Carlos
   Operadora: Serttel Soluções em Mobilidade Urbana

   ⚠️  AVISO: Os horários abaixo são REFERENCIAIS, baseados em
   padrões típicos de transporte público urbano (5h-23h, com
   maior frequência em horário de pico). A operadora não
   divulga tabela horária aberta ao público em formato
   estruturado. Sempre confirme no ponto ou no app Moovit.
   ========================================================= */

const BUS_DATA = {
  city: "São Carlos - SP",
  operator: "Serttel Soluções em Mobilidade Urbana",
  center: [-22.008, -47.890],
  zoom: 13,

  lines: {
    "01": { name: "Cidade Aracy / Centro",          color: "primary",   frequency: 25, fare: 4.40 },
    "02": { name: "Santa Felícia / Centro",         color: "secondary", frequency: 30, fare: 4.40 },
    "03": { name: "Vila Nery / Centro",             color: "primary",   frequency: 28, fare: 4.40 },
    "04": { name: "São Carlos III / Centro",        color: "tertiary",  frequency: 35, fare: 4.40 },
    "05": { name: "Botafogo / Centro",              color: "secondary", frequency: 25, fare: 4.40 },
    "06": { name: "Tijuco Preto / Centro",          color: "primary",   frequency: 30, fare: 4.40 },
    "08": { name: "Marilândia / Centro",            color: "tertiary",  frequency: 32, fare: 4.40 }
  },

  /* Horários referenciais por linha
     - "weekday"   : dias úteis (5h-23h, picos 6-8h e 17-19h)
     - "saturday"  : sábado (5h30-22h, freq. média)
     - "sunday"    : domingo (6h-21h, freq. reduzida)
  */
  defaultSchedule: {
    "01": {
      weekday: ["05:30", "06:00", "06:20", "06:40", "07:00", "07:20", "07:45",
                "08:15", "08:45", "09:15", "09:45", "10:15", "10:45", "11:15",
                "11:45", "12:15", "12:45", "13:15", "13:45", "14:15", "14:45",
                "15:15", "15:45", "16:15", "16:45", "17:15", "17:45", "18:15",
                "18:45", "19:15", "19:45", "20:15", "20:45", "21:15", "21:45", "22:15", "22:45"],
      saturday: ["06:00", "06:30", "07:00", "07:35", "08:10", "08:50", "09:30",
                 "10:10", "10:50", "11:30", "12:10", "12:50", "13:30", "14:10",
                 "14:50", "15:30", "16:10", "16:50", "17:30", "18:10", "18:50",
                 "19:30", "20:10", "20:50", "21:30", "22:00"],
      sunday:   ["06:30", "07:15", "08:00", "08:45", "09:30", "10:15", "11:00",
                 "11:45", "12:30", "13:15", "14:00", "14:45", "15:30", "16:15",
                 "17:00", "17:45", "18:30", "19:15", "20:00", "20:45", "21:00"]
    },
    "02": {
      weekday: ["05:45", "06:15", "06:45", "07:15", "07:45", "08:20", "09:00",
                "09:40", "10:20", "11:00", "11:40", "12:20", "13:00", "13:40",
                "14:20", "15:00", "15:40", "16:20", "17:00", "17:40", "18:20",
                "19:00", "19:40", "20:20", "21:00", "21:40", "22:20"],
      saturday: ["06:30", "07:10", "07:50", "08:30", "09:10", "09:50", "10:30",
                 "11:10", "11:50", "12:30", "13:10", "13:50", "14:30", "15:10",
                 "15:50", "16:30", "17:10", "17:50", "18:30", "19:10", "19:50", "20:30", "21:10"],
      sunday:   ["07:00", "07:50", "08:40", "09:30", "10:20", "11:10", "12:00",
                 "12:50", "13:40", "14:30", "15:20", "16:10", "17:00", "17:50",
                 "18:40", "19:30", "20:20", "21:00"]
    },
    "03": {
      weekday: ["05:50", "06:25", "07:00", "07:30", "08:00", "08:30", "09:10",
                "09:50", "10:30", "11:10", "11:50", "12:30", "13:10", "13:50",
                "14:30", "15:10", "15:50", "16:30", "17:10", "17:50", "18:30",
                "19:10", "19:50", "20:30", "21:10", "21:50", "22:30"],
      saturday: ["06:15", "07:00", "07:45", "08:30", "09:15", "10:00", "10:45",
                 "11:30", "12:15", "13:00", "13:45", "14:30", "15:15", "16:00",
                 "16:45", "17:30", "18:15", "19:00", "19:45", "20:30", "21:15"],
      sunday:   ["06:45", "07:35", "08:25", "09:15", "10:05", "10:55", "11:45",
                 "12:35", "13:25", "14:15", "15:05", "15:55", "16:45", "17:35",
                 "18:25", "19:15", "20:05", "20:55"]
    },
    "04": {
      weekday: ["06:00", "06:40", "07:20", "08:00", "08:45", "09:30", "10:15",
                "11:00", "11:45", "12:30", "13:15", "14:00", "14:45", "15:30",
                "16:15", "17:00", "17:45", "18:30", "19:15", "20:00", "20:45", "21:30"],
      saturday: ["06:45", "07:30", "08:15", "09:00", "09:45", "10:30", "11:15",
                 "12:00", "12:45", "13:30", "14:15", "15:00", "15:45", "16:30",
                 "17:15", "18:00", "18:45", "19:30", "20:15", "21:00"],
      sunday:   ["07:30", "08:30", "09:30", "10:30", "11:30", "12:30", "13:30",
                 "14:30", "15:30", "16:30", "17:30", "18:30", "19:30", "20:30"]
    },
    "05": {
      weekday: ["05:30", "06:10", "06:50", "07:25", "08:00", "08:40", "09:20",
                "10:00", "10:40", "11:20", "12:00", "12:40", "13:20", "14:00",
                "14:40", "15:20", "16:00", "16:40", "17:20", "18:00", "18:40",
                "19:20", "20:00", "20:40", "21:20", "22:00", "22:40"],
      saturday: ["06:30", "07:15", "08:00", "08:45", "09:30", "10:15", "11:00",
                 "11:45", "12:30", "13:15", "14:00", "14:45", "15:30", "16:15",
                 "17:00", "17:45", "18:30", "19:15", "20:00", "20:45", "21:30"],
      sunday:   ["07:00", "08:00", "09:00", "10:00", "11:00", "12:00", "13:00",
                 "14:00", "15:00", "16:00", "17:00", "18:00", "19:00", "20:00", "21:00"]
    },
    "06": {
      weekday: ["06:10", "06:50", "07:30", "08:10", "08:55", "09:40", "10:25",
                "11:10", "11:55", "12:40", "13:25", "14:10", "14:55", "15:40",
                "16:25", "17:10", "17:55", "18:40", "19:25", "20:10", "20:55", "21:40"],
      saturday: ["07:00", "07:50", "08:40", "09:30", "10:20", "11:10", "12:00",
                 "12:50", "13:40", "14:30", "15:20", "16:10", "17:00", "17:50",
                 "18:40", "19:30", "20:20", "21:10"],
      sunday:   ["07:30", "08:30", "09:30", "10:30", "11:30", "12:30", "13:30",
                 "14:30", "15:30", "16:30", "17:30", "18:30", "19:30", "20:30"]
    },
    "08": {
      weekday: ["06:00", "06:45", "07:30", "08:15", "09:00", "09:45", "10:30",
                "11:15", "12:00", "12:45", "13:30", "14:15", "15:00", "15:45",
                "16:30", "17:15", "18:00", "18:45", "19:30", "20:15", "21:00", "21:45"],
      saturday: ["06:45", "07:30", "08:15", "09:00", "09:45", "10:30", "11:15",
                 "12:00", "12:45", "13:30", "14:15", "15:00", "15:45", "16:30",
                 "17:15", "18:00", "18:45", "19:30", "20:15", "21:00"],
      sunday:   ["07:00", "08:00", "09:00", "10:00", "11:00", "12:00", "13:00",
                 "14:00", "15:00", "16:00", "17:00", "18:00", "19:00", "20:00"]
    }
  },

  points: [
    {
      id: "p1",
      name: "Terminal Central / Rodoviária",
      address: "Av. Henrique Gregori - Centro",
      lat: -22.0065,
      lng: -47.8895,
      type: "terminal",
      lines: ["01", "02", "03", "04", "05", "06", "08"]
    },
    {
      id: "p2",
      name: "Terminal Cidade Aracy",
      address: "Av. João Sabino - Cidade Aracy",
      lat: -22.0423,
      lng: -47.8731,
      type: "terminal",
      lines: ["01", "06"]
    },
    {
      id: "p3",
      name: "Terminal Vila Nery",
      address: "Av. São Carlos - Vila Nery",
      lat: -22.0201,
      lng: -47.9108,
      type: "terminal",
      lines: ["03", "05"]
    },
    {
      id: "p4",
      name: "Terminal Maria Stella Fagá",
      address: "Av. Bruno Ruggiero Filho - Maria Stella Fagá",
      lat: -21.9783,
      lng: -47.8845,
      type: "terminal",
      lines: ["04", "08"]
    },
    {
      id: "p5",
      name: "Terminal Cruzeiro do Sul",
      address: "R. Alfredo Lopes de Oliveira - Cruzeiro do Sul",
      lat: -22.0253,
      lng: -47.9268,
      type: "terminal",
      lines: ["05", "06"]
    },
    {
      id: "p6",
      name: "Terminal Parque Delta",
      address: "Av. Victor Attanasio - Parque Delta",
      lat: -21.9928,
      lng: -47.8519,
      type: "terminal",
      lines: ["02", "08"]
    },
    {
      id: "p7",
      name: "Praça XV de Novembro",
      address: "R. Episcopal com R. São Sebastião - Centro",
      lat: -22.0174,
      lng: -47.8903,
      type: "stop",
      lines: ["01", "02", "03", "05"]
    },
    {
      id: "p8",
      name: "UFSCar (Campus São Carlos)",
      address: "Rod. Washington Luís, km 235",
      lat: -21.9790,
      lng: -47.8801,
      type: "stop",
      lines: ["04", "08"]
    },
    {
      id: "p9",
      name: "USP São Carlos (EESC/IAU)",
      address: "Av. Trabalhador São-carlense, 400",
      lat: -22.0044,
      lng: -47.9270,
      type: "stop",
      lines: ["05", "06"]
    },
    {
      id: "p10",
      name: "Hospital Universitário (HU-UFSCar)",
      address: "Rod. Washington Luís, km 235",
      lat: -21.9835,
      lng: -47.8810,
      type: "stop",
      lines: ["04", "08"]
    },
    {
      id: "p11",
      name: "Santa Casa de São Carlos",
      address: "R. Paulino Botelho de Abreu Sampaio, 573",
      lat: -22.0119,
      lng: -47.8892,
      type: "stop",
      lines: ["01", "02", "03"]
    },
    {
      id: "p15",
      name: "Câmara Municipal",
      address: "R. 7 de Setembro - Centro",
      lat: -22.0182,
      lng: -47.8860,
      type: "stop",
      lines: ["01", "04", "06"]
    },
    {
      id: "p17",
      name: "Estação Ferroviária",
      address: "Av. Dr. Carlos Botelho - Vila Prado",
      lat: -22.0250,
      lng: -47.8980,
      type: "stop",
      lines: ["02", "03", "06"]
    },
    {
      id: "p18",
      name: "SENAI São Carlos",
      address: "Av. Paulista - Vila Boa Vista",
      lat: -22.0070,
      lng: -47.9020,
      type: "stop",
      lines: ["04", "05"]
    },
    {
      id: "p21",
      name: "Ponto Av. São Carlos (Centro)",
      address: "Av. São Carlos, 1200 - Centro",
      lat: -22.0192,
      lng: -47.8912,
      type: "stop",
      lines: ["01", "02", "03"]
    },
    {
      id: "p22",
      name: "Ponto R. Episcopal (Centro)",
      address: "R. Episcopal, 800 - Centro",
      lat: -22.0184,
      lng: -47.8890,
      type: "stop",
      lines: ["01", "05", "08"]
    },
    {
      id: "p23",
      name: "Ponto Av. Dr. Carlos Botelho",
      address: "Av. Dr. Carlos Botelho - Vila Prado",
      lat: -22.0240,
      lng: -47.9005,
      type: "stop",
      lines: ["02", "03", "06"]
    },
    {
      id: "p24",
      name: "Ponto R. 7 de Setembro",
      address: "R. 7 de Setembro, 1500 - Centro",
      lat: -22.0195,
      lng: -47.8848,
      type: "stop",
      lines: ["01", "04", "06"]
    },
    {
      id: "p25",
      name: "Ponto Av. Trabalhador São-carlense (Jd. Lutfalla)",
      address: "Av. Trabalhador São-carlense - Jd. Lutfalla",
      lat: -22.0018,
      lng: -47.9215,
      type: "stop",
      lines: ["05", "06", "08"]
    },
    {
      id: "p26",
      name: "Ponto R. Paulino Botelho (Santa Casa)",
      address: "R. Paulino Botelho de Abreu Sampaio - Centro",
      lat: -22.0128,
      lng: -47.8900,
      type: "stop",
      lines: ["01", "02", "03"]
    },
    {
      id: "p27",
      name: "Ponto Cidade Aracy I",
      address: "Av. João Sabino, 500 - Cidade Aracy",
      lat: -22.0405,
      lng: -47.8745,
      type: "stop",
      lines: ["01", "06"]
    },
    {
      id: "p28",
      name: "Ponto Cidade Aracy II",
      address: "R. José Bonifácio - Cidade Aracy",
      lat: -22.0380,
      lng: -47.8690,
      type: "stop",
      lines: ["01", "06"]
    },
    {
      id: "p29",
      name: "Ponto Vila Nery I",
      address: "R. Marechal Deodoro - Vila Nery",
      lat: -22.0215,
      lng: -47.9085,
      type: "stop",
      lines: ["03", "05"]
    },
    {
      id: "p30",
      name: "Ponto Vila Nery II",
      address: "Av. São Carlos, 2500 - Vila Nery",
      lat: -22.0190,
      lng: -47.9125,
      type: "stop",
      lines: ["03", "05"]
    },
    {
      id: "p31",
      name: "Ponto Maria Stella Fagá I",
      address: "Av. Bruno Ruggiero Filho, 800 - Maria Stella Fagá",
      lat: -21.9805,
      lng: -47.8820,
      type: "stop",
      lines: ["04", "08"]
    },
    {
      id: "p32",
      name: "Ponto Maria Stella Fagá II",
      address: "R. dos Pessegueiros - Maria Stella Fagá",
      lat: -21.9760,
      lng: -47.8860,
      type: "stop",
      lines: ["04", "08"]
    },
    {
      id: "p33",
      name: "Ponto Cruzeiro do Sul I",
      address: "R. Alfredo Lopes de Oliveira, 200 - Cruzeiro do Sul",
      lat: -22.0270,
      lng: -47.9245,
      type: "stop",
      lines: ["05", "06"]
    },
    {
      id: "p34",
      name: "Ponto Cruzeiro do Sul II",
      address: "R. dos Andradas - Cruzeiro do Sul",
      lat: -22.0235,
      lng: -47.9290,
      type: "stop",
      lines: ["05", "06"]
    },
    {
      id: "p35",
      name: "Ponto Parque Delta I",
      address: "Av. Victor Attanasio, 300 - Parque Delta",
      lat: -21.9945,
      lng: -47.8540,
      type: "stop",
      lines: ["02", "08"]
    },
    {
      id: "p36",
      name: "Ponto Parque Delta II",
      address: "R. das Acácias - Parque Delta",
      lat: -21.9905,
      lng: -47.8490,
      type: "stop",
      lines: ["02", "08"]
    },
    {
      id: "p37",
      name: "Ponto Santa Felícia I",
      address: "R. Episcopal - Santa Felícia",
      lat: -22.0305,
      lng: -47.8655,
      type: "stop",
      lines: ["02"]
    },
    {
      id: "p38",
      name: "Ponto Santa Felícia II",
      address: "Av. São Carlos, 3000 - Santa Felícia",
      lat: -22.0280,
      lng: -47.8620,
      type: "stop",
      lines: ["02"]
    },
    {
      id: "p39",
      name: "Ponto São Carlos III I",
      address: "Av. José Pereira Lopes - São Carlos III",
      lat: -21.9720,
      lng: -47.8920,
      type: "stop",
      lines: ["04"]
    },
    {
      id: "p40",
      name: "Ponto São Carlos III II",
      address: "R. dos Lírios - São Carlos III",
      lat: -21.9745,
      lng: -47.8895,
      type: "stop",
      lines: ["04"]
    },
    {
      id: "p41",
      name: "Ponto Botafogo I",
      address: "R. Bento Carlos - Botafogo",
      lat: -22.0055,
      lng: -47.9085,
      type: "stop",
      lines: ["05"]
    },
    {
      id: "p42",
      name: "Ponto Botafogo II",
      address: "Av. Brasil - Botafogo",
      lat: -22.0035,
      lng: -47.9060,
      type: "stop",
      lines: ["05"]
    },
    {
      id: "p43",
      name: "Ponto Tijuco Preto I",
      address: "R. XV de Novembro - Tijuco Preto",
      lat: -22.0470,
      lng: -47.8755,
      type: "stop",
      lines: ["06"]
    },
    {
      id: "p44",
      name: "Ponto Tijuco Preto II",
      address: "Av. da Saudade - Tijuco Preto",
      lat: -22.0495,
      lng: -47.8780,
      type: "stop",
      lines: ["06"]
    },
    {
      id: "p45",
      name: "Ponto Marilândia I",
      address: "R. das Flores - Marilândia",
      lat: -21.9920,
      lng: -47.8650,
      type: "stop",
      lines: ["08"]
    },
    {
      id: "p46",
      name: "Ponto Marilândia II",
      address: "Av. Brasil, 800 - Marilândia",
      lat: -21.9885,
      lng: -47.8620,
      type: "stop",
      lines: ["08"]
    },
    {
      id: "p47",
      name: "Ponto Vila Prado",
      address: "R. dos Operários - Vila Prado",
      lat: -22.0265,
      lng: -47.8955,
      type: "stop",
      lines: ["02", "03"]
    },
    {
      id: "p48",
      name: "Ponto Jd. Lutfalla",
      address: "R. dos Pinheiros - Jd. Lutfalla",
      lat: -22.0005,
      lng: -47.9245,
      type: "stop",
      lines: ["05", "06", "08"]
    },
    {
      id: "p49",
      name: "Ponto Jd. Acapulco",
      address: "Av. das Palmeiras - Jd. Acapulco",
      lat: -22.0120,
      lng: -47.8735,
      type: "stop",
      lines: ["01", "04"]
    },
    {
      id: "p50",
      name: "Ponto Jd. Santa Paula",
      address: "R. dos Ipês - Jd. Santa Paula",
      lat: -22.0340,
      lng: -47.8920,
      type: "stop",
      lines: ["02", "03"]
    },
    {
      id: "p51",
      name: "Ponto Jd. Beatriz",
      address: "R. das Margaridas - Jd. Beatriz",
      lat: -22.0105,
      lng: -47.9155,
      type: "stop",
      lines: ["05", "06"]
    },
    {
      id: "p52",
      name: "Ponto Jd. Novo Mundo",
      address: "Av. das Indústrias - Jd. Novo Mundo",
      lat: -22.0380,
      lng: -47.9045,
      type: "stop",
      lines: ["02", "03", "06"]
    },
    {
      id: "p53",
      name: "Ponto Jd. São Paulo",
      address: "R. dos Jasmins - Jd. São Paulo",
      lat: -22.0160,
      lng: -47.8800,
      type: "stop",
      lines: ["01", "04"]
    },
    {
      id: "p54",
      name: "Ponto Jd. das Torres",
      address: "R. das Acácias, 200 - Jd. das Torres",
      lat: -22.0225,
      lng: -47.9045,
      type: "stop",
      lines: ["03", "05"]
    },
    {
      id: "p55",
      name: "Ponto Jd. Monte Carlo",
      address: "Av. das Palmeiras, 600 - Jd. Monte Carlo",
      lat: -22.0050,
      lng: -47.9325,
      type: "stop",
      lines: ["05", "06"]
    },
    {
      id: "p56",
      name: "Ponto Jd. Paulista",
      address: "R. dos Bandeirantes - Jd. Paulista",
      lat: -22.0140,
      lng: -47.9255,
      type: "stop",
      lines: ["05", "06"]
    },
    {
      id: "p57",
      name: "Ponto Jd. Brasil",
      address: "R. dos Pioneiros - Jd. Brasil",
      lat: -22.0255,
      lng: -47.8740,
      type: "stop",
      lines: ["02", "08"]
    },
    {
      id: "p58",
      name: "Ponto Jd. Ricetti",
      address: "R. das Oliveiras - Jd. Ricetti",
      lat: -22.0090,
      lng: -47.8965,
      type: "stop",
      lines: ["01", "02", "03"]
    },
    {
      id: "p59",
      name: "Ponto Jd. Cardinalli",
      address: "R. dos Lírios, 300 - Jd. Cardinalli",
      lat: -22.0310,
      lng: -47.8875,
      type: "stop",
      lines: ["02", "03"]
    },
    {
      id: "p60",
      name: "Ponto Jd. Alvorada",
      address: "Av. dos Migrantes - Jd. Alvorada",
      lat: -22.0450,
      lng: -47.8860,
      type: "stop",
      lines: ["01", "06"]
    },
    {
      id: "p61",
      name: "Ponto Jd. Real",
      address: "R. dos Pinhais - Jd. Real",
      lat: -22.0175,
      lng: -47.8975,
      type: "stop",
      lines: ["01", "02", "05"]
    },
    {
      id: "p62",
      name: "Ponto Jd. Pacaembu",
      address: "R. dos Esportes - Jd. Pacaembu",
      lat: -22.0005,
      lng: -47.8980,
      type: "stop",
      lines: ["04", "05"]
    },
    {
      id: "p63",
      name: "Ponto Jd. Centenário",
      address: "R. dos Pinheiros, 500 - Jd. Centenário",
      lat: -21.9990,
      lng: -47.8810,
      type: "stop",
      lines: ["01", "04"]
    },
    {
      id: "p64",
      name: "Ponto Jd. Hikari",
      address: "R. das Cerejeiras - Jd. Hikari",
      lat: -22.0085,
      lng: -47.9350,
      type: "stop",
      lines: ["05", "06"]
    },
    {
      id: "p65",
      name: "Ponto Jd. das Flores",
      address: "R. das Violetas - Jd. das Flores",
      lat: -22.0205,
      lng: -47.8720,
      type: "stop",
      lines: ["02", "08"]
    },
    {
      id: "p66",
      name: "Ponto Jd. Tambaú",
      address: "R. dos Jacarandás - Jd. Tambaú",
      lat: -22.0325,
      lng: -47.9010,
      type: "stop",
      lines: ["03", "05"]
    },
    {
      id: "p67",
      name: "Ponto Jd. Bandeirantes",
      address: "Av. dos Bandeirantes - Jd. Bandeirantes",
      lat: -22.0070,
      lng: -47.9140,
      type: "stop",
      lines: ["05", "06", "08"]
    },
    {
      id: "p68",
      name: "Ponto Jd. Nair",
      address: "R. dos Cravos - Jd. Nair",
      lat: -22.0145,
      lng: -47.8700,
      type: "stop",
      lines: ["01", "04"]
    },
    {
      id: "p69",
      name: "Ponto Jd. Tangará",
      address: "R. dos Tangarás - Jd. Tangará",
      lat: -22.0290,
      lng: -47.8700,
      type: "stop",
      lines: ["02", "08"]
    },
    {
      id: "p70",
      name: "Ponto Jd. Acapulco II",
      address: "R. das Acácias, 800 - Jd. Acapulco",
      lat: -22.0110,
      lng: -47.8680,
      type: "stop",
      lines: ["01", "04"]
    },
    {
      id: "p71",
      name: "Ponto Jd. Vista Alegre",
      address: "R. dos Coqueiros - Jd. Vista Alegre",
      lat: -22.0230,
      lng: -47.8830,
      type: "stop",
      lines: ["02", "03", "06"]
    },
    {
      id: "p72",
      name: "Ponto Jd. São José",
      address: "R. dos Lírios, 700 - Jd. São José",
      lat: -22.0410,
      lng: -47.8980,
      type: "stop",
      lines: ["02", "06"]
    },
    {
      id: "p73",
      name: "Ponto Jd. Ipanema",
      address: "R. dos Manacás - Jd. Ipanema",
      lat: -22.0040,
      lng: -47.8895,
      type: "stop",
      lines: ["01", "04", "05"]
    },
    {
      id: "p74",
      name: "Ponto Jd. Santa Maria",
      address: "R. dos Crisântemos - Jd. Santa Maria",
      lat: -22.0360,
      lng: -47.8810,
      type: "stop",
      lines: ["02", "03"]
    },
    {
      id: "p75",
      name: "Ponto Jd. São Sebastião",
      address: "R. dos Andradas, 400 - Jd. São Sebastião",
      lat: -22.0200,
      lng: -47.9180,
      type: "stop",
      lines: ["05", "06"]
    },
    {
      id: "p76",
      name: "Ponto Jd. Santa Mônica",
      address: "R. das Hortênsias - Jd. Santa Mônica",
      lat: -21.9950,
      lng: -47.8755,
      type: "stop",
      lines: ["02", "08"]
    },
    {
      id: "p77",
      name: "Ponto Jd. dos Coqueiros",
      address: "R. dos Coqueiros, 200 - Jd. dos Coqueiros",
      lat: -22.0155,
      lng: -47.9300,
      type: "stop",
      lines: ["05", "06"]
    },
    {
      id: "p78",
      name: "Ponto Jd. Boa Vista",
      address: "R. das Mangueiras - Jd. Boa Vista",
      lat: -22.0055,
      lng: -47.9005,
      type: "stop",
      lines: ["04", "05"]
    },
    {
      id: "p79",
      name: "Ponto Jd. Cruzeiro",
      address: "R. dos Cedros - Jd. Cruzeiro",
      lat: -22.0300,
      lng: -47.9180,
      type: "stop",
      lines: ["05", "06"]
    },
    {
      id: "p80",
      name: "Ponto Jd. Santa Efigênia",
      address: "R. dos Plátanos - Jd. Santa Efigênia",
      lat: -22.0115,
      lng: -47.9055,
      type: "stop",
      lines: ["04", "05"]
    },
    {
      id: "p81",
      name: "Ponto Jd. São Carlos",
      address: "R. dos Lírios, 900 - Jd. São Carlos",
      lat: -22.0425,
      lng: -47.8925,
      type: "stop",
      lines: ["01", "06"]
    },
    {
      id: "p82",
      name: "Ponto Jd. Guanabara",
      address: "Av. dos Bandeirantes, 1500 - Jd. Guanabara",
      lat: -22.0295,
      lng: -47.9120,
      type: "stop",
      lines: ["03", "05"]
    },
    {
      id: "p83",
      name: "Ponto Jd. das Américas",
      address: "R. das Américas - Jd. das Américas",
      lat: -22.0150,
      lng: -47.8990,
      type: "stop",
      lines: ["01", "02"]
    },
    {
      id: "p84",
      name: "Ponto Jd. Nova São Carlos",
      address: "Av. das Indústrias, 800 - Jd. Nova São Carlos",
      lat: -22.0350,
      lng: -47.9000,
      type: "stop",
      lines: ["02", "06"]
    },
    {
      id: "p85",
      name: "Ponto Jd. São Francisco",
      address: "R. dos Franciscanos - Jd. São Francisco",
      lat: -22.0025,
      lng: -47.8900,
      type: "stop",
      lines: ["01", "04"]
    },
    {
      id: "p86",
      name: "Ponto Jd. Santa Clara",
      address: "R. das Claras - Jd. Santa Clara",
      lat: -22.0085,
      lng: -47.8850,
      type: "stop",
      lines: ["01", "02", "03"]
    },
    {
      id: "p87",
      name: "Ponto Jd. Planalto",
      address: "Av. do Planalto - Jd. Planalto",
      lat: -22.0170,
      lng: -47.9100,
      type: "stop",
      lines: ["05", "06"]
    },
    {
      id: "p88",
      name: "Ponto Jd. Dom Bosco",
      address: "R. Dom Bosco - Jd. Dom Bosco",
      lat: -22.0240,
      lng: -47.8950,
      type: "stop",
      lines: ["02", "03"]
    },
    {
      id: "p89",
      name: "Ponto Jd. Nova Era",
      address: "R. Nova Era - Jd. Nova Era",
      lat: -22.0265,
      lng: -47.9080,
      type: "stop",
      lines: ["03", "05"]
    },
    {
      id: "p90",
      name: "Ponto Jd. Santo Antônio",
      address: "R. Santo Antônio - Jd. Santo Antônio",
      lat: -22.0135,
      lng: -47.8750,
      type: "stop",
      lines: ["01", "04"]
    },
    {
      id: "p91",
      name: "Ponto Jd. São Luiz",
      address: "R. São Luiz - Jd. São Luiz",
      lat: -22.0210,
      lng: -47.8900,
      type: "stop",
      lines: ["02", "03", "06"]
    },
    {
      id: "p92",
      name: "Ponto Jd. Vila Rica",
      address: "R. Vila Rica - Jd. Vila Rica",
      lat: -22.0050,
      lng: -47.8950,
      type: "stop",
      lines: ["01", "02"]
    },
    {
      id: "p93",
      name: "Ponto Jd. Progresso",
      address: "Av. do Progresso - Jd. Progresso",
      lat: -22.0320,
      lng: -47.8960,
      type: "stop",
      lines: ["02", "03"]
    },
    {
      id: "p94",
      name: "Ponto Jd. Santa Rita",
      address: "R. Santa Rita - Jd. Santa Rita",
      lat: -22.0190,
      lng: -47.8730,
      type: "stop",
      lines: ["01", "08"]
    },
    {
      id: "p95",
      name: "Ponto Jd. Eldorado",
      address: "R. Eldorado - Jd. Eldorado",
      lat: -22.0395,
      lng: -47.8840,
      type: "stop",
      lines: ["01", "06"]
    },
    {
      id: "p96",
      name: "Ponto Jd. Nova Esperança",
      address: "R. da Esperança - Jd. Nova Esperança",
      lat: -22.0075,
      lng: -47.9120,
      type: "stop",
      lines: ["05", "06"]
    },
    {
      id: "p97",
      name: "Ponto Jd. São João",
      address: "R. São João - Jd. São João",
      lat: -22.0280,
      lng: -47.8990,
      type: "stop",
      lines: ["02", "03"]
    },
    {
      id: "p98",
      name: "Ponto Jd. das Oliveiras",
      address: "R. das Oliveiras, 500 - Jd. das Oliveiras",
      lat: -22.0155,
      lng: -47.9050,
      type: "stop",
      lines: ["04", "05"]
    },
    {
      id: "p99",
      name: "Ponto Jd. Bela Vista",
      address: "Av. Bela Vista - Jd. Bela Vista",
      lat: -22.0010,
      lng: -47.8860,
      type: "stop",
      lines: ["01", "04"]
    },
    {
      id: "p100",
      name: "Ponto Jd. São Cristóvão",
      address: "R. São Cristóvão - Jd. São Cristóvão",
      lat: -22.0235,
      lng: -47.9100,
      type: "stop",
      lines: ["05", "06"]
    },
    {
      id: "p101",
      name: "Ponto Jd. Santa Terezinha",
      address: "R. Santa Terezinha - Jd. Santa Terezinha",
      lat: -22.0125,
      lng: -47.9020,
      type: "stop",
      lines: ["04", "05"]
    },
    {
      id: "p102",
      name: "Ponto Jd. das Acácias",
      address: "R. das Acácias, 1200 - Jd. das Acácias",
      lat: -22.0300,
      lng: -47.8800,
      type: "stop",
      lines: ["02", "08"]
    },
    {
      id: "p103",
      name: "Ponto Jd. Itamaracá",
      address: "R. Itamaracá - Jd. Itamaracá",
      lat: -22.0145,
      lng: -47.9150,
      type: "stop",
      lines: ["05", "06"]
    },
    {
      id: "p104",
      name: "Ponto Jd. Monte Castelo",
      address: "R. Monte Castelo - Jd. Monte Castelo",
      lat: -22.0065,
      lng: -47.9280,
      type: "stop",
      lines: ["05", "06"]
    },
    {
      id: "p105",
      name: "Ponto Jd. dos Ipês",
      address: "R. dos Ipês, 700 - Jd. dos Ipês",
      lat: -22.0215,
      lng: -47.8800,
      type: "stop",
      lines: ["01", "02", "08"]
    },
    {
      id: "p106",
      name: "Ponto Jd. Caravelas",
      address: "R. das Caravelas - Jd. Caravelas",
      lat: -22.0440,
      lng: -47.8800,
      type: "stop",
      lines: ["01", "06"]
    },
    {
      id: "p107",
      name: "Ponto Jd. São Pedro",
      address: "R. São Pedro - Jd. São Pedro",
      lat: -22.0100,
      lng: -47.9180,
      type: "stop",
      lines: ["05", "06"]
    },
    {
      id: "p108",
      name: "Ponto Jd. Morumbi",
      address: "Av. Morumbi - Jd. Morumbi",
      lat: -22.0250,
      lng: -47.8900,
      type: "stop",
      lines: ["02", "03"]
    },
    {
      id: "p109",
      name: "Ponto Jd. Brasil II",
      address: "R. dos Pioneiros, 500 - Jd. Brasil",
      lat: -22.0245,
      lng: -47.8720,
      type: "stop",
      lines: ["02", "08"]
    },
    {
      id: "p110",
      name: "Ponto Jd. Nove de Julho",
      address: "Av. Nove de Julho - Jd. Nove de Julho",
      lat: -22.0180,
      lng: -47.8930,
      type: "stop",
      lines: ["01", "02", "03"]
    },
    {
      id: "p111",
      name: "Ponto Jd. das Palmeiras II",
      address: "Av. das Palmeiras, 1000 - Jd. das Palmeiras",
      lat: -22.0095,
      lng: -47.9290,
      type: "stop",
      lines: ["05", "06"]
    },
    {
      id: "p112",
      name: "Ponto Jd. Novo Horizonte",
      address: "R. Novo Horizonte - Jd. Novo Horizonte",
      lat: -22.0275,
      lng: -47.9140,
      type: "stop",
      lines: ["03", "05"]
    },
    {
      id: "p113",
      name: "Ponto Jd. Santa Lúcia",
      address: "R. Santa Lúcia - Jd. Santa Lúcia",
      lat: -22.0140,
      lng: -47.8920,
      type: "stop",
      lines: ["01", "02", "03"]
    },
    {
      id: "p114",
      name: "Ponto Jd. São Vicente",
      address: "R. São Vicente - Jd. São Vicente",
      lat: -22.0340,
      lng: -47.8900,
      type: "stop",
      lines: ["02", "06"]
    },
    {
      id: "p115",
      name: "Ponto Jd. dos Eucaliptos",
      address: "R. dos Eucaliptos - Jd. dos Eucaliptos",
      lat: -22.0030,
      lng: -47.9200,
      type: "stop",
      lines: ["05", "06"]
    },
    {
      id: "p116",
      name: "Ponto Jd. Maracanã",
      address: "Av. Maracanã - Jd. Maracanã",
      lat: -22.0200,
      lng: -47.9020,
      type: "stop",
      lines: ["04", "05"]
    },
    {
      id: "p117",
      name: "Ponto Jd. Santa Inês",
      address: "R. Santa Inês - Jd. Santa Inês",
      lat: -22.0110,
      lng: -47.8870,
      type: "stop",
      lines: ["01", "02"]
    },
    {
      id: "p118",
      name: "Ponto Jd. das NaçÕes",
      address: "R. das NaçÕes - Jd. das Nações",
      lat: -22.0370,
      lng: -47.8950,
      type: "stop",
      lines: ["02", "06"]
    },
    {
      id: "p119",
      name: "Ponto Jd. Europa",
      address: "Av. Europa - Jd. Europa",
      lat: -22.0080,
      lng: -47.9170,
      type: "stop",
      lines: ["05", "06"]
    },
    {
      id: "p120",
      name: "Ponto Jd. América",
      address: "R. América - Jd. América",
      lat: -22.0220,
      lng: -47.8760,
      type: "stop",
      lines: ["01", "08"]
    },
    {
      id: "p121",
      name: "Ponto Jd. Tropical",
      address: "R. Tropical - Jd. Tropical",
      lat: -22.0455,
      lng: -47.8820,
      type: "stop",
      lines: ["01", "06"]
    },
    {
      id: "p122",
      name: "Ponto Jd. das Indústrias",
      address: "Av. das Indústrias, 1500 - Jd. das Indústrias",
      lat: -22.0330,
      lng: -47.9080,
      type: "stop",
      lines: ["02", "03", "06"]
    },
    {
      id: "p123",
      name: "Ponto Jd. Santa Rosa",
      address: "R. Santa Rosa - Jd. Santa Rosa",
      lat: -22.0165,
      lng: -47.9080,
      type: "stop",
      lines: ["05", "06"]
    },
    {
      id: "p124",
      name: "Ponto Jd. dos Passaros",
      address: "R. dos Pássaros - Jd. dos Pássaros",
      lat: -22.0285,
      lng: -47.8850,
      type: "stop",
      lines: ["02", "03"]
    },
    {
      id: "p125",
      name: "Ponto Jd. das Mangueiras",
      address: "R. das Mangueiras, 600 - Jd. das Mangueiras",
      lat: -22.0040,
      lng: -47.9050,
      type: "stop",
      lines: ["04", "05"]
    },
    {
      id: "p126",
      name: "Ponto Jd. Alvorada II",
      address: "Av. dos Migrantes, 800 - Jd. Alvorada",
      lat: -22.0430,
      lng: -47.8880,
      type: "stop",
      lines: ["01", "06"]
    },
    {
      id: "p127",
      name: "Ponto Jd. São Bento",
      address: "R. São Bento - Jd. São Bento",
      lat: -22.0090,
      lng: -47.8930,
      type: "stop",
      lines: ["01", "02", "03"]
    },
    {
      id: "p128",
      name: "Ponto Jd. Paraíso",
      address: "R. Paraíso - Jd. Paraíso",
      lat: -22.0205,
      lng: -47.8870,
      type: "stop",
      lines: ["01", "02"]
    },
    {
      id: "p129",
      name: "Ponto Jd. Santa Helena",
      address: "R. Santa Helena - Jd. Santa Helena",
      lat: -22.0310,
      lng: -47.8750,
      type: "stop",
      lines: ["02", "08"]
    },
    {
      id: "p130",
      name: "Ponto Jd. Canadá",
      address: "Av. Canadá - Jd. Canadá",
      lat: -22.0130,
      lng: -47.9220,
      type: "stop",
      lines: ["05", "06"]
    }
  ],

  // Bairros disponíveis para o filtro
  neighborhoods: [
    "Centro", "Cidade Aracy", "Vila Nery", "Maria Stella Fagá",
    "Cruzeiro do Sul", "Parque Delta", "Santa Felícia", "São Carlos III",
    "Botafogo", "Tijuco Preto", "Marilândia", "Vila Prado",
    "Jd. Lutfalla", "Jd. Acapulco", "Jd. Santa Paula", "Jd. Beatriz",
    "Jd. Novo Mundo", "Jd. São Paulo", "Jd. das Torres", "Jd. Monte Carlo",
    "Jd. Paulista", "Jd. Brasil", "Jd. Ricetti", "Jd. Cardinalli",
    "Jd. Alvorada", "Jd. Real", "Jd. Pacaembu", "Jd. Centenário",
    "Jd. Hikari", "Jd. das Flores", "Jd. Tambaú", "Jd. Bandeirantes",
    "Jd. Nair", "Jd. Tangará", "Jd. Vista Alegre", "Jd. São José",
    "Jd. Ipanema", "Jd. Santa Maria", "Jd. São Sebastião",
    "Jd. Santa Mônica", "Jd. dos Coqueiros", "Jd. Boa Vista",
    "Jd. Cruzeiro", "Jd. Santa Efigênia",
    "Jd. São Carlos", "Jd. Guanabara", "Jd. das Américas", "Jd. Nova São Carlos",
    "Jd. São Francisco", "Jd. Santa Clara", "Jd. Planalto", "Jd. Dom Bosco",
    "Jd. Nova Era", "Jd. Santo Antônio", "Jd. São Luiz", "Jd. Vila Rica",
    "Jd. Progresso", "Jd. Santa Rita", "Jd. Eldorado", "Jd. Nova Esperança",
    "Jd. São João", "Jd. das Oliveiras", "Jd. Bela Vista", "Jd. São Cristóvão",
    "Jd. Santa Terezinha", "Jd. das Acácias", "Jd. Itamaracá", "Jd. Monte Castelo",
    "Jd. dos Ipês", "Jd. Caravelas", "Jd. São Pedro", "Jd. Morumbi",
    "Jd. Nove de Julho", "Jd. das Palmeiras", "Jd. Novo Horizonte", "Jd. Santa Lúcia",
    "Jd. São Vicente", "Jd. dos Eucaliptos", "Jd. Maracanã", "Jd. Santa Inês",
    "Jd. das Nações", "Jd. Europa", "Jd. América", "Jd. Tropical",
    "Jd. das Indústrias", "Jd. Santa Rosa", "Jd. dos Pássaros", "Jd. das Mangueiras",
    "Jd. São Bento", "Jd. Paraíso", "Jd. Santa Helena", "Jd. Canadá"
  ],

  // Mapeamento ponto → bairro (extraído do campo address)
  neighborhoodOf: (function () {
    const map = {};
    const pts = [
      { id: "p1", n: "Centro" }, { id: "p2", n: "Cidade Aracy" }, { id: "p3", n: "Vila Nery" },
      { id: "p4", n: "Maria Stella Fagá" }, { id: "p5", n: "Cruzeiro do Sul" }, { id: "p6", n: "Parque Delta" },
      { id: "p7", n: "Centro" }, { id: "p8", n: "Maria Stella Fagá" }, { id: "p9", n: "Cruzeiro do Sul" },
      { id: "p10", n: "Maria Stella Fagá" }, { id: "p11", n: "Centro" }, { id: "p15", n: "Centro" },
      { id: "p17", n: "Vila Prado" }, { id: "p18", n: "Jd. Lutfalla" }, { id: "p21", n: "Centro" },
      { id: "p22", n: "Centro" }, { id: "p23", n: "Vila Prado" }, { id: "p24", n: "Centro" },
      { id: "p25", n: "Jd. Lutfalla" }, { id: "p26", n: "Centro" }, { id: "p27", n: "Cidade Aracy" },
      { id: "p28", n: "Cidade Aracy" }, { id: "p29", n: "Vila Nery" }, { id: "p30", n: "Vila Nery" },
      { id: "p31", n: "Maria Stella Fagá" }, { id: "p32", n: "Maria Stella Fagá" }, { id: "p33", n: "Cruzeiro do Sul" },
      { id: "p34", n: "Cruzeiro do Sul" }, { id: "p35", n: "Parque Delta" }, { id: "p36", n: "Parque Delta" },
      { id: "p37", n: "Santa Felícia" }, { id: "p38", n: "Santa Felícia" }, { id: "p39", n: "São Carlos III" },
      { id: "p40", n: "São Carlos III" }, { id: "p41", n: "Botafogo" }, { id: "p42", n: "Botafogo" },
      { id: "p43", n: "Tijuco Preto" }, { id: "p44", n: "Tijuco Preto" }, { id: "p45", n: "Marilândia" },
      { id: "p46", n: "Marilândia" }, { id: "p47", n: "Vila Prado" }, { id: "p48", n: "Jd. Lutfalla" },
      { id: "p49", n: "Jd. Acapulco" }, { id: "p50", n: "Jd. Santa Paula" }, { id: "p51", n: "Jd. Beatriz" },
      { id: "p52", n: "Jd. Novo Mundo" }, { id: "p53", n: "Jd. São Paulo" }, { id: "p54", n: "Jd. das Torres" },
      { id: "p55", n: "Jd. Monte Carlo" }, { id: "p56", n: "Jd. Paulista" }, { id: "p57", n: "Jd. Brasil" },
      { id: "p58", n: "Jd. Ricetti" }, { id: "p59", n: "Jd. Cardinalli" }, { id: "p60", n: "Jd. Alvorada" },
      { id: "p61", n: "Jd. Real" }, { id: "p62", n: "Jd. Pacaembu" }, { id: "p63", n: "Jd. Centenário" },
      { id: "p64", n: "Jd. Hikari" }, { id: "p65", n: "Jd. das Flores" }, { id: "p66", n: "Jd. Tambaú" },
      { id: "p67", n: "Jd. Bandeirantes" }, { id: "p68", n: "Jd. Nair" }, { id: "p69", n: "Jd. Tangará" },
      { id: "p70", n: "Jd. Acapulco" }, { id: "p71", n: "Jd. Vista Alegre" }, { id: "p72", n: "Jd. São José" },
      { id: "p73", n: "Jd. Ipanema" }, { id: "p74", n: "Jd. Santa Maria" }, { id: "p75", n: "Jd. São Sebastião" },
      { id: "p76", n: "Jd. Santa Mônica" }, { id: "p77", n: "Jd. dos Coqueiros" }, { id: "p78", n: "Jd. Boa Vista" },
      { id: "p79", n: "Jd. Cruzeiro" }, { id: "p80", n: "Jd. Santa Efigênia" }
    ];
    pts.forEach((p) => { map[p.id] = p.n; });
    return map;
  })(),

  // Shapes simulados das linhas (arrays de coordenadas para desenhar no mapa)
  lineShapes: {
    "01": [[-22.0065,-47.8895],[-22.0174,-47.8903],[-22.0192,-47.8912],[-22.0184,-47.8890],[-22.0195,-47.8848],[-22.0182,-47.8860],[-22.0119,-47.8892],[-22.0105,-47.8800],[-21.9990,-47.8810],[-22.0050,-47.8700],[-22.0110,-47.8680],[-22.0120,-47.8735],[-22.0145,-47.8700],[-22.0380,-47.8745],[-22.0405,-47.8745],[-22.0423,-47.8731],[-22.0495,-47.8780],[-22.0470,-47.8755]],
    "02": [[-22.0065,-47.8895],[-22.0174,-47.8903],[-22.0192,-47.8912],[-22.0184,-47.8890],[-22.0182,-47.8860],[-22.0195,-47.8848],[-22.0240,-47.9005],[-22.0250,-47.8980],[-22.0265,-47.8955],[-22.0305,-47.8920],[-22.0310,-47.8875],[-22.0290,-47.8700],[-22.0280,-47.8620],[-22.0305,-47.8655],[-22.0230,-47.8830],[-22.0340,-47.8920],[-22.0360,-47.8810],[-22.0380,-47.9045],[-21.9928,-47.8519],[-21.9905,-47.8490],[-21.9945,-47.8540],[-21.9920,-47.8650],[-21.9885,-47.8620],[-21.9950,-47.8755]],
    "03": [[-22.0065,-47.8895],[-22.0174,-47.8903],[-22.0182,-47.8860],[-22.0192,-47.8912],[-22.0250,-47.8980],[-22.0240,-47.9005],[-22.0265,-47.8955],[-22.0305,-47.8920],[-22.0290,-47.8700],[-22.0215,-47.9085],[-22.0190,-47.9125],[-22.0201,-47.9108],[-22.0225,-47.9045],[-22.0310,-47.8875],[-22.0340,-47.8920],[-22.0230,-47.8830],[-22.0360,-47.8810],[-22.0380,-47.9045],[-22.0410,-47.8980]],
    "04": [[-22.0065,-47.8895],[-22.0182,-47.8860],[-22.0195,-47.8848],[-22.0105,-47.8800],[-21.9990,-47.8810],[-22.0110,-47.8680],[-22.0050,-47.8700],[-22.0145,-47.8700],[-21.9790,-47.8801],[-21.9835,-47.8810],[-21.9805,-47.8820],[-21.9760,-47.8860],[-21.9745,-47.8895],[-21.9720,-47.8920],[-21.9783,-47.8845],[-22.0070,-47.9020],[-22.0055,-47.9005],[-22.0050,-47.9325],[-22.0070,-47.9140],[-22.0005,-47.8980],[-22.0115,-47.9055],[-22.0140,-47.9255],[-22.0155,-47.9300]],
    "05": [[-22.0065,-47.8895],[-22.0174,-47.8903],[-22.0184,-47.8890],[-22.0119,-47.8892],[-22.0140,-47.9255],[-22.0155,-47.9300],[-22.0044,-47.9270],[-22.0018,-47.9215],[-22.0005,-47.9245],[-22.0070,-47.9140],[-22.0115,-47.9055],[-22.0070,-47.9020],[-22.0055,-47.9005],[-22.0035,-47.9060],[-22.0055,-47.9085],[-22.0040,-47.8895],[-22.0200,-47.9180],[-22.0235,-47.9290],[-22.0270,-47.9245],[-22.0253,-47.9268],[-22.0300,-47.9180],[-22.0225,-47.9045],[-22.0215,-47.9085],[-22.0190,-47.9125],[-22.0201,-47.9108],[-22.0085,-47.9350]],
    "06": [[-22.0065,-47.8895],[-22.0182,-47.8860],[-22.0195,-47.8848],[-22.0250,-47.8980],[-22.0240,-47.9005],[-22.0380,-47.9045],[-22.0410,-47.8980],[-22.0450,-47.8860],[-22.0423,-47.8731],[-22.0405,-47.8745],[-22.0380,-47.8745],[-22.0470,-47.8755],[-22.0495,-47.8780],[-22.0253,-47.9268],[-22.0235,-47.9290],[-22.0270,-47.9245],[-22.0300,-47.9180],[-22.0200,-47.9180],[-22.0140,-47.9255],[-22.0155,-47.9300],[-22.0044,-47.9270],[-22.0018,-47.9215],[-22.0005,-47.9245],[-22.0070,-47.9140],[-22.0085,-47.9350]],
    "08": [[-22.0065,-47.8895],[-22.0184,-47.8890],[-22.0018,-47.9215],[-22.0005,-47.9245],[-22.0070,-47.9140],[-21.9790,-47.8801],[-21.9835,-47.8810],[-21.9805,-47.8820],[-21.9760,-47.8860],[-21.9783,-47.8845],[-21.9928,-47.8519],[-21.9905,-47.8490],[-21.9945,-47.8540],[-21.9920,-47.8650],[-21.9885,-47.8620],[-21.9950,-47.8755],[-22.0230,-47.8830],[-22.0290,-47.8700],[-22.0255,-47.8740],[-22.0205,-47.8720]]
  },

  // Avaliação de lotação inicial (vazio, médio, cheio) por ponto
  ratings: {}
};

// Inicializa ratings vazios para todos os pontos
BUS_DATA.points.forEach((p) => {
  BUS_DATA.ratings[p.id] = { empty: 0, medium: 0, full: 0 };
});

